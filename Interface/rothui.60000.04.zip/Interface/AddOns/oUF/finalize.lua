local parent, ns = ...

-- It's named Private for a reason!
ns.oUF.Private = nil
